const CACHE="mis-misiones-v2";const ASSETS=["./","./index.html","./manifest.webmanifest","./sw.js","./images/alimentacion.png","./images/higiene.png","./images/energia.png","./images/dormir.png"];
self.addEventListener("install",e=>e.waitUntil(caches.open(CACHE).then(c=>c.addAll(ASSETS))));
self.addEventListener("fetch",e=>e.respondWith(caches.match(e.request).then(r=>r||fetch(e.request))));
