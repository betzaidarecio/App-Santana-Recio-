MIS PEQUEÑAS MISIONES 2.0

Incluye:
- 3 perfiles: Violeta (13), Elizeo (9) y Misael (7).
- Perfil independiente para cada niño.
- Horario editable por deber.
- Estrellas por cada tarea completada.
- Racha diaria tipo juego: aumenta cuando se completan todos los deberes activos del día.
- Bonos de racha: 3 días, 7 días, 14 días y 30 días.
- Las estrellas, tareas, horarios y progreso se guardan en el dispositivo.
- Preguntas interactivas para las cuatro escenas proporcionadas.
- PWA instalable y proyecto Android.

Nota:
La PWA permite instalar la experiencia desde Chrome en Android. La versión APK está preparada como proyecto Android, pero este entorno no tiene el Android SDK para compilar y firmar un .apk directamente.
